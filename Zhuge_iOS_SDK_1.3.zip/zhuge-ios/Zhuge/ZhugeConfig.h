#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Either turn on ARC for the project or use -fobjc-arc flag on this file.
#endif
//
//  ZhugeConfig.h
//
//  Copyright (c) 2014 37degree. All rights reserved.
//

#import <Foundation/Foundation.h>

/* SDK版本 */
#define ZG_SDK_VERSION @"1.2"

/* 默认应用版本 */
#define ZG_APP_VERSION [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

/* 渠道 */
#define ZG_CHANNEL @"App Store"

@interface ZhugeConfig : NSObject

#pragma mark - 基本设置
// SDK版本
@property (nonatomic, copy) NSString *sdkVersion;
// 应用版本(默认:info.plist中CFBundleShortVersionString对应的值)
@property (nonatomic, copy) NSString *appVersion;
// 渠道(默认:@"App Store")
@property (nonatomic, copy) NSString *channel;
// 两次会话时间间隔(默认:30秒)
@property (nonatomic) NSUInteger sessionInterval;

#pragma mark - 发送策略
// 上报时间间隔(默认:10秒)
@property (nonatomic) NSUInteger sendInterval;
// 每天最大上报事件数，超出部分缓存到本地(默认:1000个)
@property (nonatomic) NSUInteger sendMaxSizePerDay;
// 本地缓存事件数(默认:1000个)
@property (nonatomic) NSUInteger cacheMaxSize;

#pragma mark - 日志
// 是否开启SDK日志打印(默认:关闭)
@property (nonatomic) BOOL logEnabled;
// 是否开启崩溃报告(默认:开启)
@property (nonatomic) BOOL crashReportEnabled;

@end
