//
//  AppDelegate.h
//  HelloZhuge
//
//  Copyright (c) 2014 37degree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, NSStreamDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

